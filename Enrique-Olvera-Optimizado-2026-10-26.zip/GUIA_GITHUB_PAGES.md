# Actualizar GitHub Pages con la versión optimizada

Esta entrega parte de `ebd0c60` del repositorio `EnriqueOlveraMonroy/enriqueolveramonroy.github.io`. No se ha subido ni publicado automáticamente.

1. Conserva una copia o descarga el ZIP de la versión actual desde GitHub antes de actualizar.
2. Descomprime `Enrique-Olvera-Optimizado-2026-10-26.zip`.
3. En tu repositorio abre **Add file → Upload files** y sube el contenido del ZIP extraído, no el ZIP ni una carpeta contenedora adicional. Incluye los nuevos `.webp`, `noscript.css`, `404.html`, `robots.txt` y `sitemap.xml` además de los archivos existentes. No borres los PNG: son el respaldo de los formatos modernos y las imágenes originales de las vistas ampliadas.
4. Conserva `index.html` en la raíz y `.nojekyll`. En Finder puedes mostrar archivos ocultos con **⌘ + Shift + .**.
5. Revisa los cambios y guarda en la rama que publica Pages (normalmente `main`). Guardar en esa rama publica la actualización: hazlo cuando quieras ponerla en producción.
6. La configuración existente de **Settings → Pages → Deploy from a branch → main → /(root)** sigue siendo válida. No hay compilación ni instalación para ejecutar la página.
7. Cuando termine el proceso en **Actions**, abre el sitio y recarga con **⌘ + Shift + R**. Comprueba EN/ES, filtros, imágenes, reintento, CV y móvil. Abre también una ruta inexistente para verificar el 404 del hosting.

## Vista previa y comprobaciones opcionales

Desde la carpeta extraída, con Python 3 instalado:

```sh
python3 qa/serve.py
```

Abre `http://127.0.0.1:8000/`. Detén el servidor con `Ctrl+C`.

Con Node.js instalado, sin instalar paquetes para esta comprobación:

```sh
node qa/check-site.mjs
```

La guía `qa/README.md` describe pruebas opcionales de navegador. Estas herramientas no forman parte del funcionamiento de la web.

## Mantenimiento

- Inglés y estructura: `index.html`.
- Español, imágenes del visor y datos de notebooks: `app.js`.
- Apariencia: `styles.css`.
- Recursos: `assets/`.
- Una captura reemplazada necesita actualizar tanto su PNG como su WebP. El navegador prefiere WebP cuando está disponible.
- El contenido estático de notebooks y `portfolioProjects` deben mantenerse coordinados; el primero proporciona contenido sin JavaScript y el segundo las traducciones.
- Si cambias el dominio, actualiza canonical, Open Graph, JSON-LD, sitemap, robots y los enlaces absolutos de `404.html`.
- Si editas el bloque JSON-LD, actualiza su hash CSP. `qa/check-site.mjs` detecta discrepancias; no habilites `unsafe-inline` para evitar actualizarlo.

## Recuperación

Si una actualización falla, puedes restaurar los archivos desde la copia anterior o revertir el commit de publicación en GitHub. No elimines el repositorio. Los sitios de Sites y GitHub Pages siguen siendo independientes.
